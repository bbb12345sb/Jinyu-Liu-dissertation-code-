See 'notebook' folder for main code
The database folder is 'dataset'.